
for i in range(10):
    print("The Hall Monitor")